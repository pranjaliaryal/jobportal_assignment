﻿namespace JobPortal.Models.EntityModels
{
    public class Common
    {
        public string? CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }

        public string? UpdatedBy { get; set; }

        public DateTime? UpdatedDate { get; set; }

        public string? DeltetedBy { get; set; }

        public DateTime? DeltetedDate { get; set; }







    }
}
